﻿using GTA;
using GTA.Native;
using System;
using System.IO;
using System.Windows.Forms;



public class IdleAnimations : Script
{
    string ScriptName = "Idle Animations";
    string ScriptVer = "1.1";
    int GameTimeRef = Game.GameTime+20000;
    bool IsIdling = false;
    string IdleScenario= "WORLD_HUMAN_AA_SMOKE";
    public IdleAnimations()
    {
        Tick += OnTick;
        LoadSettings();
    }

    void OnTick(object sender, EventArgs e)
    {
        if (IsIdling)
        {
            if (Game.IsControlPressed(2, GTA.Control.VehicleAccelerate) || Game.IsControlPressed(2, GTA.Control.VehicleBrake) || Game.IsControlPressed(2, GTA.Control.VehicleMoveLeft)|| Game.IsControlPressed(2, GTA.Control.VehicleMoveRight)
                || Game.Player.Character.IsRagdoll)
            {
                Game.Player.Character.Task.ClearAll();
                IsIdling = false;
                GameTimeRef = Game.GameTime;
            }
        }
        else
        {
            if (Game.Player.Character.IsOnFoot)
            {
                if (!Game.Player.Character.IsStopped || Game.Player.Character.IsInCover() || Game.Player.IsAiming) GameTimeRef = Game.GameTime;
                else if (Game.GameTime > GameTimeRef + 10000)
                {
                    IsIdling = true;
                    Function.Call(GTA.Native.Hash.TASK_START_SCENARIO_IN_PLACE, Game.Player.Character, IdleScenario, -1, false);
                }
            }
        }
    }

    void LoadSettings()
    {
        if (File.Exists(@"scripts\IdleAnimations.ini"))
        {
            ScriptSettings config = ScriptSettings.Load(@"scripts\IdleAnimations.ini");
            IdleScenario = config.GetValue<string>("SETTINGS", "IdleAnimation", "WORLD_HUMAN_AA_SMOKE");
        }

    }
}
